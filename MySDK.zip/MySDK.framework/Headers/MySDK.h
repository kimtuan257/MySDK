//
//  MySDK.h
//  MySDK
//
//  Created by Tuan Le on 9/30/19.
//  Copyright © 2019 Tuan Le. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MySDK.
FOUNDATION_EXPORT double MySDKVersionNumber;

//! Project version string for MySDK.
FOUNDATION_EXPORT const unsigned char MySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySDK/PublicHeader.h>


